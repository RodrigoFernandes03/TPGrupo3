from django.contrib import admin
from .models import alunos
admin.site.register(alunos)

# Register your models here.
