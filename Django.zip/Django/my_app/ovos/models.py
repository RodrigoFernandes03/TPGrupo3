from django.db import models

# Create your models here.
class cliente (models.Model):
    id_customer = models.BigAutoField(primary_key=True)
    customer_name = models.CharField(max_length=150)
    customer_number = models.IntegerField()

def __str__(self):
    return str(self.customer_name)

class bolos (models.Model):
    id_bolos = models.BigAutoField(primary_key=True)
    nome_bolos = models.CharField(max_length=150)
    quantidade_bolos = models.IntegerField()
def __str__(self):
    return str (self.nome_bolos)

class funcionarios(models.Model):
    id_funcionarios = models.BigAutoField(primary_key=True)
    nome_funcionarios = models.CharField(max_length=150)
    funcao_funcionarios = models.CharField(max_length=200)
    
def __str__(self):
    return str (self.nome_funcionario)

class Vendas(models.Model):
    id_vendas = models.BigAutoField(primary_key=True)
    cliente = models.CharField(max_length=150)
    produto = models.CharField(max_length=150)
    quantidade = models.IntegerField()

def __str__(self):
    return str (self.cliente_vendas)
 
class Stock(models.Model):
    id_STOCK = models.BigAutoField(primary_key=True)
    Produto_Em_Stock = models.CharField(max_length=150)
    Quantidade_De_Produtos_Em_Stock = models.IntegerField()
    Quantidade_De_Produtos_Em_Falta_No_Stock = models.IntegerField()
    Quantidade_De_Produtos_Total_Que_Tem_De_Ter_Em_Stock = models.IntegerField()

def __str__(self):
    return str (self.Produto_Em_Stock)


    