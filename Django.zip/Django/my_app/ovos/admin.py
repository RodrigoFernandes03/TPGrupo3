from django.contrib import admin
from .models import cliente
admin.site.register(cliente)
from django.contrib import admin
from .models import bolos
admin.site.register(bolos)
from django.contrib import admin
from .models import funcionarios
admin.site.register(funcionarios)
from django.contrib import admin
from .models import Vendas
admin.site.register(Vendas)
from .models import Stock
admin.site.register(Stock)
# Register your models here.
