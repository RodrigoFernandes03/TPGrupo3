from django.db import models

# Create your models here.
class alunos(models.Model):
    id_alunos=models.BigAutoField(primary_key=True)
    aluno_nome=models.CharField(max_length=250)
    aluno_nota=models.IntegerField(max_length=150)

def __str__(self):
    return str(self.aluno_nome)

